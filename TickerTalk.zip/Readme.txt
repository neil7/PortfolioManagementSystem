_______________________________________________________________________________________________________________
  Highlights-

- How to use bcrypt to encrypt password and store in DB
- Using express Session and middlewares
- Perform complex NO SQL transcation
- Focus on accessibity of the application to visually impaired community ex- blind or color blind people, validating against 
  Tota11y app
- writing syntatically correct HTML using apt tags and validating the code againt a HTML Validator
_______________________________________________________________________________________________________________
use seed.js to populate data before starting

CS546 Final Project: Ticker Talk

Group Member: (Group 18)

Rajat Verma
Deep Chitroda

GitHub Link: https://github.com/vermarajat22255/web_programming

Setup Guide:

"npm install": Install all the modules

"npm run-script seed": Seed the database with initial data

"npm start": Start Web server

Go to the browser and hit "localhost:3000/"

Extra Feature:
Search by speech : Initialize the speech script by double tapping any where in body when you want to control
Say -signup : (if it hears something like sign, it will lead you to signup page),
     login - (leads to login page)
     any stockname : leads to search results
     If not these 3, will notify invalid search query]
